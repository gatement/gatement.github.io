﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LinQTraining.Code
{
    public class Author
    {
        public string Name
        {
            get;
            set;
        }

        public string Sex
        {
            get;
            set;
        }

        public int Age
        {
            get;
            set;
        }

        public List<string> Books
        {
            get;
            set;
        }
    }
}
