﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

namespace LinQTraining.Code
{
    public class Book : IComparable
    {
        public string Name
        {
            get;
            set;
        }

        public int Price
        {
            set;
            get;
        }

        public string Author
        {
            set;
            get;
        }

        // if the GetHashCode() equals, then:
        public override bool Equals(object obj)
        {
            Book book = obj as Book;
            Console.WriteLine("Book.Equals()");
            return (object)book != null && book.Price == this.Price && book.Author == this.Author && book.Name == this.Name;
        }

        public override int GetHashCode()
        {
            Console.WriteLine("Book.GetHashCode()");
            int result = this.Price;

            if (this.Name != null)
                result ^= this.Name.GetHashCode();

            return result;
        }

        public int CompareTo(object obj)
        {
            Console.WriteLine("Book.CompareTo()");
            Book book = obj as Book;
            return this.Price.CompareTo(book.Price);
        }

        public static bool operator ==(Book b1, Book b2)
        {
            return b1.Equals(b2);
        }

        public static bool operator !=(Book b1, Book b2)
        {
            return !b1.Equals(b2);
        }
    }
}
