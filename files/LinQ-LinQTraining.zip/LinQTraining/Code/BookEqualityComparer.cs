﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LinQTraining.Code
{
    class BookEqualityComparer: IEqualityComparer<Book>
    {
        public bool Equals(Book x, Book y)
        {
            Console.WriteLine("BookEqualityComparer.Equals()");
            return x.Name.Equals(y.Name);
        }

        public int GetHashCode(Book obj)
        {
            Console.WriteLine("BookEqualityComparer.GetHashCode()");
            return 123;
        }
    }
}
