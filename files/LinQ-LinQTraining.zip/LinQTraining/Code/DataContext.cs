﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LinQTraining.Code
{
    class DataContext
    {
        public static Author[] Authors =
		{
			new Author{Name = "Max", Age = 30, Sex = "Male", Books = new List<string>{"My First","My Love","On Cloud","Programing of C#","A little sand","Look! God","Fish on fly","War of US-wide", "Shut My Heart", "Oh, Babe"}},
			new Author{Name = "God", Age = 200, Sex = "Male", Books = new List<string>{"B1111111112","B3","B1","B4","B5"}},
			new Author{Name = "Bibone", Age = 16, Sex = "Female", Books = new List<string>{"aaa","bbb","ccc"}},
			new Author{Name = "Alone", Age = 100, Sex = "Male", Books = new List<string>{}}
		};

        public static Book[] Books = 
		{
			new Book{Name = "My First", Author = "Max", Price = 100},
			new Book{Name = "My Love", Author = "Max", Price = 100},
			new Book{Name = "B2", Author = "God", Price = 60},
			new Book{Name = "B2", Author = "God", Price = 50},
			new Book{Name = "B3", Author = "God", Price = 50},
			new Book{Name = "On Cloud", Author = "Max", Price = 200},
			new Book{Name = "Programing of C#", Author = "Max", Price = 400},
			new Book{Name = "A little sand", Author = "Max", Price = 500},

			new Book{Name = "aaa", Author = "Bibone", Price = 100},
			new Book{Name = "bbb", Author = "Bibone", Price = 250},
			new Book{Name = "Look! God", Author = "Max", Price = 400},
			new Book{Name = "Fish on fly", Author = "Max", Price = 400},
			new Book{Name = "ccc", Author = "Bibone", Price = 250},

			new Book{Name = "B1", Author = "God", Price = 300},
			new Book{Name = "War of US-wide", Author = "Max", Price = 200},
			new Book{Name = "Shut My Heart", Author = "Max", Price = 200},
			new Book{Name = "Oh, Babe", Author = "Max", Price = 300},
			new Book{Name = "B4", Author = "God", Price = 50},
			new Book{Name = "B5", Author = "God", Price = 300}
		};

        public static Writer[] Writers = 
        {
            new Writer{Name="Johnson", Book=new Book{Name="ASP.NET Programming", Author="Johnson", Price=100}},
            new Writer{Name="Max", Book=new Book{Name="C# Programming", Author="Max", Price=200}}
        };

        public static Publisher[] Publishers = 
        {            
            new Publisher{Name="YYY", Book=new Book{Name="ASP.NET Programming", Author="Johnson", Price=150}},
            new Publisher{Name="XXX", Book=new Book{Name="C# Programming", Author="Max", Price=200}}
        };
    }
}
