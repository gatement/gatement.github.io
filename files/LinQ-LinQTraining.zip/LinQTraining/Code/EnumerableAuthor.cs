﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LinQTraining.Code
{
    class EnumerableAuthor : IEnumerable<Book>
    {
        #region Constructor

        public EnumerableAuthor(string name)
        {
            this.Name = name;
        }

        #endregion

        #region Class members

        public string Name
        {
            get;
            set;
        }

        public List<Book> Books
        {
            get;
            set;
        }

        #endregion

        #region IEnumerable and IEnumerable<Book> members

        public IEnumerator<Book> GetEnumerator()
        {
            return new InnerEnumerator(this);
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return new InnerEnumerator(this);
        }

        #endregion

        private class InnerEnumerator : IEnumerator<Book>
        {
            EnumerableAuthor author;
            private int currentPosition = -1;

            public InnerEnumerator(EnumerableAuthor author)
            {
                this.author = author;
            }

            #region IEnumerator<Book> members

            public Book Current
            {
                get
                {
                    return this.author.Books[currentPosition];
                }
            }

            object IEnumerator.Current
            {
                get
                {
                    return this.author.Books[currentPosition];
                }
            }

            public bool MoveNext()
            {
                if((this.currentPosition + 1) >= this.author.Books.Count)
                {
                    return false;
                }
                else
                {
                    this.currentPosition++;
                    return true;
                }
            }

            public void Reset()
            {
                this.currentPosition = -1;
            }

            #endregion

            #region IDisposable members

            public void Dispose()
            {
                // do nothing
            }

            #endregion
        }
    }
}
