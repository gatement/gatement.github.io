﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LinQTraining.Code
{
    public static class IEnumerableExtender
    {
        public static void RaisePrice(this Book book, int increment)
        {
            book.Price += increment;
        }

        public static IEnumerable<T> MyWhere<T>(this IEnumerable<T> source, Func<T, bool> predicate)
        {
            // IEnumerable<Book> books = DataContext.Books.Where(book => book.Price > 300);

            List<T> result=new List<T>();

            foreach(T item in source)
            {
                if(predicate(item))
                {
                    result.Add(item);
                }
            }

            return result;
        }

        public static IEnumerable<T> MyWhere2<T>(this IEnumerable<T> source, Func<T, bool> predicate)
        {
            // IEnumerable<Book> books = DataContext.Books.Where(book => book.Price > 300);

            foreach(T item in source)
            {
                if(predicate(item))
                {
                    yield return item;
                }
            }
        }

        public static IEnumerable<T> MyWhere3<T>(this IEnumerable<T> source, Func<T, bool> predicate)
        {
            return new MyEnumerableClass<T>(source, predicate);
        }

        public static IEnumerable<TResult> MySelectMany<TSource, TResult>(this IEnumerable<TSource> source, Func<TSource, IEnumerable<TResult>> selector)
        {
            //var books3 = DataContext.Authors.SelectMany(author => author.Books);

            List<TResult> result = new List<TResult>();

            foreach(TSource item in source)
            {
                IEnumerable<TResult> subCollection = selector(item);

                foreach(TResult resultItem in subCollection)
                {
                    result.Add(resultItem);
                }
            }

            return result;
        }

        public static IEnumerable<TResult> MyJoin<TOuter, TInner, TKey, TResult>(this IEnumerable<TOuter> outer, IEnumerable<TInner> inner, Func<TOuter, TKey> outerKeySelector, Func<TInner, TKey> innerKeySelector, Func<TOuter, TInner, TResult> resultSelector)
        {
            foreach (TOuter outerItem in outer)
            {
                foreach (TInner innerItem in inner)
                {
                    if (outerKeySelector(outerItem).Equals(innerKeySelector(innerItem)))
                    {
                        yield return resultSelector(outerItem, innerItem);
                    }
                }
            }
        }

        public static IEnumerable<TResult> MyGroupJoin<TOuter, TInner, TKey, TResult>(this IEnumerable<TOuter> outer, IEnumerable<TInner> inner, Func<TOuter, TKey> outerKeySelector, Func<TInner, TKey> innerKeySelector, Func<TOuter, IEnumerable<TInner>, TResult> resultSelector)
        {
            // DataContext.Authors.GroupJoin(DataContext.Books,
            //    author => author.Name,
            //    book => book.Author,
            //    (author, books) => new { Author = author.Name, Books = books });
            foreach (TOuter outerItem in outer)
            {
                List<TInner> inners = new List<TInner>();
                foreach (TInner innerItem in inner)
                {
                    if (outerKeySelector(outerItem).Equals(innerKeySelector(innerItem)))
                    {
                        inners.Add(innerItem);
                    }
                }

                yield return resultSelector(outerItem, inners);
            }
        }
    }

    public class MyEnumerableClass<T> : IEnumerable<T>
    {
        private IEnumerable<T> source;
        private Func<T, bool> predicate;

        public MyEnumerableClass(IEnumerable<T> source, Func<T, bool> predicate)
        {
            this.source = source;
            this.predicate = predicate;
        }

        public IEnumerator<T> GetEnumerator()
        {
            return new MyEnumeratorClass(this);
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return (IEnumerator)this.GetEnumerator();
        }

        private class MyEnumeratorClass : IEnumerator<T>
        {
            private MyEnumerableClass<T> parent;
            private int currentPosition = -1;
            private T current;

            public MyEnumeratorClass(MyEnumerableClass<T> parent)
            {
                this.parent = parent;
            }

            public T Current
            {
                get
                {
                    return this.current;
                }
            }

            object IEnumerator.Current
            {
                get
                {
                    return this.Current;
                }
            }

            public bool MoveNext()
            {
                for(currentPosition++; currentPosition < this.parent.source.Count(); currentPosition++)
                {
                    T item = this.parent.source.ElementAt(this.currentPosition);

                    if(this.parent.predicate(item))
                    {
                        this.current = item;
                        break;
                    }
                }

                if(currentPosition < this.parent.source.Count())
                    return true;
                else
                    return false;
            }

            public void Reset()
            {
                this.currentPosition = -1;
                this.current = default(T);
            }

            public void Dispose()
            {
                // do nothing
            }
        }
    }
}
