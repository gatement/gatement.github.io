﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LinQTraining.Code
{
    class MyComparer<T>: IComparer<T>
    {
        private Func<T, T, int> predicate;

        public MyComparer(Func<T, T, int> predicate)
        {
            this.predicate = predicate;
        }

        public int Compare(T x, T y)
        {
            return predicate(x, y);
        }
    }
}
