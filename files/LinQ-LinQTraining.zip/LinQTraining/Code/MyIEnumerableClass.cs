﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LinQTraining.Code
{
    class MyIEnumerableClass
    {
        public MyIEnumerableClass()
        {
            this.Items = new List<string>();
        }

        public List<string> Items
        {
            get;
            set;
        }

        public IEnumerable<string> Where(Func<string, bool> predicate)
        {
            Console.WriteLine("MyIEnumerableClass.Where()");
            return Items.Where(item => item.Contains('a'));
        }
    }
}
