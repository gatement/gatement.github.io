﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;

namespace LinQTraining.Code
{
    public static class MyQueryableExtender
    {
        public static IQueryable<TSource> MyQWhere<TSource>(this IQueryable<TSource> source, Expression predicate)
        {
            MethodCallExpression exp = Expression.Call(typeof(Queryable), "Where", new Type[] { typeof(TSource) }, source.Expression, predicate);

            return source.Provider.CreateQuery<TSource>(exp);
        }

        public static IQueryable<TSource> MyQOrderBy<TSource, TKey>(this IQueryable<TSource> source, Expression keySelector)
        {
            MethodCallExpression exp = Expression.Call(typeof(Queryable), "OrderBy", new Type[] { typeof(TSource), typeof(TKey) }, source.Expression, keySelector);

            return source.Provider.CreateQuery<TSource>(exp);
        }

        public static IQueryable<TResult> MyQSelect<TSource, TResult>(this IQueryable<TSource> source, Expression resultSelector)
        {
            MethodCallExpression exp = Expression.Call(typeof(Queryable), "Select", new Type[] { typeof(TSource), typeof(TResult) }, source.Expression, resultSelector);

            return source.Provider.CreateQuery<TResult>(exp);
        }
        
    }
}
