﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LinQTraining.Code
{
    public class MyList<T> : List<T>
    {
        public IEnumerable<T> Where(Func<T, bool> predicate)
        {
            Console.WriteLine("Implemented by MyList<T>.");

            return Enumerable.Where(this, predicate);
        }
    }
}
