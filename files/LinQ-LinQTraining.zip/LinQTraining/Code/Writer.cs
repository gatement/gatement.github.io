﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LinQTraining.Code
{
    class Writer
    {
        public string Name
        {
            get;
            set;
        }

        public Book Book
        {
            get;
            set;
        }
    }
}
