﻿namespace LinQTraining
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if(disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnClose = new System.Windows.Forms.Button();
            this.btnDelegate = new System.Windows.Forms.Button();
            this.btnClosure2 = new System.Windows.Forms.Button();
            this.btnLambda = new System.Windows.Forms.Button();
            this.btnExtender = new System.Windows.Forms.Button();
            this.btnClosure = new System.Windows.Forms.Button();
            this.btnTest = new System.Windows.Forms.Button();
            this.gbPrecondition = new System.Windows.Forms.GroupBox();
            this.btnSample = new System.Windows.Forms.Button();
            this.btnVar = new System.Windows.Forms.Button();
            this.btnIEnumerable = new System.Windows.Forms.Button();
            this.btnImplementBySelf = new System.Windows.Forms.Button();
            this.btnDelayFunction = new System.Windows.Forms.Button();
            this.btnFunctionToQuery = new System.Windows.Forms.Button();
            this.btnHalfFlow = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnAsEnumerable = new System.Windows.Forms.Button();
            this.btnSelfMethod = new System.Windows.Forms.Button();
            this.btnClosureEffect = new System.Windows.Forms.Button();
            this.btnCast = new System.Windows.Forms.Button();
            this.btnEqualityComparer = new System.Windows.Forms.Button();
            this.btnComparer = new System.Windows.Forms.Button();
            this.btnWhere = new System.Windows.Forms.Button();
            this.btnThenBy = new System.Windows.Forms.Button();
            this.btnThenByDescending = new System.Windows.Forms.Button();
            this.btnOrderByDescending = new System.Windows.Forms.Button();
            this.btnSelectMany = new System.Windows.Forms.Button();
            this.btnSelect = new System.Windows.Forms.Button();
            this.btnOrderBy = new System.Windows.Forms.Button();
            this.btnGroupJoin = new System.Windows.Forms.Button();
            this.btnJoin = new System.Windows.Forms.Button();
            this.btnGroupBy = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnAsQuerable = new System.Windows.Forms.Button();
            this.btnImplementQueryableBySelf = new System.Windows.Forms.Button();
            this.btnExpressionSample3 = new System.Windows.Forms.Button();
            this.btnQuerableIntroduce = new System.Windows.Forms.Button();
            this.btnUsingExpressionInIEnumerable = new System.Windows.Forms.Button();
            this.btnExpressionSample2 = new System.Windows.Forms.Button();
            this.btnExpressionSample1 = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.gbPrecondition.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(12, 519);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(938, 71);
            this.btnClose.TabIndex = 0;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnDelegate
            // 
            this.btnDelegate.Location = new System.Drawing.Point(6, 48);
            this.btnDelegate.Name = "btnDelegate";
            this.btnDelegate.Size = new System.Drawing.Size(216, 23);
            this.btnDelegate.TabIndex = 1;
            this.btnDelegate.Text = "Delegate";
            this.btnDelegate.UseVisualStyleBackColor = true;
            this.btnDelegate.Click += new System.EventHandler(this.btnDelegate_Click);
            // 
            // btnClosure2
            // 
            this.btnClosure2.Location = new System.Drawing.Point(6, 135);
            this.btnClosure2.Name = "btnClosure2";
            this.btnClosure2.Size = new System.Drawing.Size(216, 23);
            this.btnClosure2.TabIndex = 2;
            this.btnClosure2.Text = "Closure2";
            this.btnClosure2.UseVisualStyleBackColor = true;
            this.btnClosure2.Click += new System.EventHandler(this.btnClosure2_Click);
            // 
            // btnLambda
            // 
            this.btnLambda.Location = new System.Drawing.Point(6, 77);
            this.btnLambda.Name = "btnLambda";
            this.btnLambda.Size = new System.Drawing.Size(216, 23);
            this.btnLambda.TabIndex = 3;
            this.btnLambda.Text = "Lambda";
            this.btnLambda.UseVisualStyleBackColor = true;
            this.btnLambda.Click += new System.EventHandler(this.btnLambda_Click);
            // 
            // btnExtender
            // 
            this.btnExtender.Location = new System.Drawing.Point(6, 222);
            this.btnExtender.Name = "btnExtender";
            this.btnExtender.Size = new System.Drawing.Size(216, 23);
            this.btnExtender.TabIndex = 4;
            this.btnExtender.Text = "Extention Method";
            this.btnExtender.UseVisualStyleBackColor = true;
            this.btnExtender.Click += new System.EventHandler(this.btnExtender_Click);
            // 
            // btnClosure
            // 
            this.btnClosure.Location = new System.Drawing.Point(6, 106);
            this.btnClosure.Name = "btnClosure";
            this.btnClosure.Size = new System.Drawing.Size(216, 23);
            this.btnClosure.TabIndex = 5;
            this.btnClosure.Text = "Closure";
            this.btnClosure.UseVisualStyleBackColor = true;
            this.btnClosure.Click += new System.EventHandler(this.btnClosure_Click);
            // 
            // btnTest
            // 
            this.btnTest.Location = new System.Drawing.Point(12, 448);
            this.btnTest.Name = "btnTest";
            this.btnTest.Size = new System.Drawing.Size(938, 65);
            this.btnTest.TabIndex = 6;
            this.btnTest.Text = "Test";
            this.btnTest.UseVisualStyleBackColor = true;
            this.btnTest.Click += new System.EventHandler(this.btnTest_Click);
            // 
            // gbPrecondition
            // 
            this.gbPrecondition.Controls.Add(this.btnSample);
            this.gbPrecondition.Controls.Add(this.btnVar);
            this.gbPrecondition.Controls.Add(this.btnDelegate);
            this.gbPrecondition.Controls.Add(this.btnLambda);
            this.gbPrecondition.Controls.Add(this.btnExtender);
            this.gbPrecondition.Controls.Add(this.btnClosure);
            this.gbPrecondition.Controls.Add(this.btnClosure2);
            this.gbPrecondition.Controls.Add(this.btnIEnumerable);
            this.gbPrecondition.Location = new System.Drawing.Point(12, 12);
            this.gbPrecondition.Name = "gbPrecondition";
            this.gbPrecondition.Size = new System.Drawing.Size(230, 430);
            this.gbPrecondition.TabIndex = 7;
            this.gbPrecondition.TabStop = false;
            this.gbPrecondition.Text = "Precondition";
            // 
            // btnSample
            // 
            this.btnSample.Location = new System.Drawing.Point(6, 19);
            this.btnSample.Name = "btnSample";
            this.btnSample.Size = new System.Drawing.Size(216, 23);
            this.btnSample.TabIndex = 9;
            this.btnSample.Text = "First Sample";
            this.btnSample.UseVisualStyleBackColor = true;
            this.btnSample.Click += new System.EventHandler(this.btnSample_Click);
            // 
            // btnVar
            // 
            this.btnVar.Location = new System.Drawing.Point(6, 193);
            this.btnVar.Name = "btnVar";
            this.btnVar.Size = new System.Drawing.Size(216, 23);
            this.btnVar.TabIndex = 14;
            this.btnVar.Text = "var && new && anonymous object";
            this.btnVar.UseVisualStyleBackColor = true;
            this.btnVar.Click += new System.EventHandler(this.btnVar_Click);
            // 
            // btnIEnumerable
            // 
            this.btnIEnumerable.Location = new System.Drawing.Point(6, 164);
            this.btnIEnumerable.Name = "btnIEnumerable";
            this.btnIEnumerable.Size = new System.Drawing.Size(216, 23);
            this.btnIEnumerable.TabIndex = 8;
            this.btnIEnumerable.Text = "IEnumerable";
            this.btnIEnumerable.UseVisualStyleBackColor = true;
            this.btnIEnumerable.Click += new System.EventHandler(this.btnIEnumerable_Click);
            // 
            // btnImplementBySelf
            // 
            this.btnImplementBySelf.Location = new System.Drawing.Point(6, 135);
            this.btnImplementBySelf.Name = "btnImplementBySelf";
            this.btnImplementBySelf.Size = new System.Drawing.Size(216, 23);
            this.btnImplementBySelf.TabIndex = 10;
            this.btnImplementBySelf.Text = "Implement by Self (Immediately 即时)";
            this.btnImplementBySelf.UseVisualStyleBackColor = true;
            this.btnImplementBySelf.Click += new System.EventHandler(this.btnImplementBySelf_Click);
            // 
            // btnDelayFunction
            // 
            this.btnDelayFunction.Location = new System.Drawing.Point(6, 164);
            this.btnDelayFunction.Name = "btnDelayFunction";
            this.btnDelayFunction.Size = new System.Drawing.Size(216, 23);
            this.btnDelayFunction.TabIndex = 11;
            this.btnDelayFunction.Text = "deferred execution - 延时(流式)";
            this.btnDelayFunction.UseVisualStyleBackColor = true;
            this.btnDelayFunction.Click += new System.EventHandler(this.btnDelayFunction_Click);
            // 
            // btnFunctionToQuery
            // 
            this.btnFunctionToQuery.Location = new System.Drawing.Point(6, 19);
            this.btnFunctionToQuery.Name = "btnFunctionToQuery";
            this.btnFunctionToQuery.Size = new System.Drawing.Size(216, 23);
            this.btnFunctionToQuery.TabIndex = 12;
            this.btnFunctionToQuery.Text = "Function to Query";
            this.btnFunctionToQuery.UseVisualStyleBackColor = true;
            this.btnFunctionToQuery.Click += new System.EventHandler(this.btnFunctionToQuery_Click);
            // 
            // btnHalfFlow
            // 
            this.btnHalfFlow.Location = new System.Drawing.Point(6, 193);
            this.btnHalfFlow.Name = "btnHalfFlow";
            this.btnHalfFlow.Size = new System.Drawing.Size(216, 23);
            this.btnHalfFlow.TabIndex = 13;
            this.btnHalfFlow.Text = "半流式";
            this.btnHalfFlow.UseVisualStyleBackColor = true;
            this.btnHalfFlow.Click += new System.EventHandler(this.btnHalfFlow_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnAsEnumerable);
            this.groupBox1.Controls.Add(this.btnSelfMethod);
            this.groupBox1.Controls.Add(this.btnClosureEffect);
            this.groupBox1.Controls.Add(this.btnCast);
            this.groupBox1.Controls.Add(this.btnImplementBySelf);
            this.groupBox1.Controls.Add(this.btnDelayFunction);
            this.groupBox1.Controls.Add(this.btnFunctionToQuery);
            this.groupBox1.Controls.Add(this.btnEqualityComparer);
            this.groupBox1.Controls.Add(this.btnComparer);
            this.groupBox1.Controls.Add(this.btnHalfFlow);
            this.groupBox1.Location = new System.Drawing.Point(248, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(231, 430);
            this.groupBox1.TabIndex = 14;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Enumerable";
            // 
            // btnAsEnumerable
            // 
            this.btnAsEnumerable.Location = new System.Drawing.Point(6, 280);
            this.btnAsEnumerable.Name = "btnAsEnumerable";
            this.btnAsEnumerable.Size = new System.Drawing.Size(216, 23);
            this.btnAsEnumerable.TabIndex = 16;
            this.btnAsEnumerable.Text = "AsEnumerable()";
            this.btnAsEnumerable.UseVisualStyleBackColor = true;
            this.btnAsEnumerable.Click += new System.EventHandler(this.btnAsEnumerable_Click);
            // 
            // btnSelfMethod
            // 
            this.btnSelfMethod.Location = new System.Drawing.Point(6, 48);
            this.btnSelfMethod.Name = "btnSelfMethod";
            this.btnSelfMethod.Size = new System.Drawing.Size(216, 23);
            this.btnSelfMethod.TabIndex = 5;
            this.btnSelfMethod.Text = "Queryable Class";
            this.btnSelfMethod.UseVisualStyleBackColor = true;
            this.btnSelfMethod.Click += new System.EventHandler(this.btnSelfMethod_Click);
            // 
            // btnClosureEffect
            // 
            this.btnClosureEffect.Location = new System.Drawing.Point(6, 222);
            this.btnClosureEffect.Name = "btnClosureEffect";
            this.btnClosureEffect.Size = new System.Drawing.Size(216, 23);
            this.btnClosureEffect.TabIndex = 15;
            this.btnClosureEffect.Text = "Closure Effect";
            this.btnClosureEffect.UseVisualStyleBackColor = true;
            this.btnClosureEffect.Click += new System.EventHandler(this.btnClosureEffect_Click);
            // 
            // btnCast
            // 
            this.btnCast.Location = new System.Drawing.Point(6, 251);
            this.btnCast.Name = "btnCast";
            this.btnCast.Size = new System.Drawing.Size(216, 23);
            this.btnCast.TabIndex = 15;
            this.btnCast.Text = "Cast<T>()";
            this.btnCast.UseVisualStyleBackColor = true;
            this.btnCast.Click += new System.EventHandler(this.btnCast_Click);
            // 
            // btnEqualityComparer
            // 
            this.btnEqualityComparer.Location = new System.Drawing.Point(6, 77);
            this.btnEqualityComparer.Name = "btnEqualityComparer";
            this.btnEqualityComparer.Size = new System.Drawing.Size(216, 23);
            this.btnEqualityComparer.TabIndex = 13;
            this.btnEqualityComparer.Text = "EqualityComparer";
            this.btnEqualityComparer.UseVisualStyleBackColor = true;
            this.btnEqualityComparer.Click += new System.EventHandler(this.btnEqualityComparer_Click);
            // 
            // btnComparer
            // 
            this.btnComparer.Location = new System.Drawing.Point(6, 106);
            this.btnComparer.Name = "btnComparer";
            this.btnComparer.Size = new System.Drawing.Size(216, 23);
            this.btnComparer.TabIndex = 13;
            this.btnComparer.Text = "Comparer";
            this.btnComparer.UseVisualStyleBackColor = true;
            this.btnComparer.Click += new System.EventHandler(this.btnComparer_Click);
            // 
            // btnWhere
            // 
            this.btnWhere.Location = new System.Drawing.Point(8, 19);
            this.btnWhere.Name = "btnWhere";
            this.btnWhere.Size = new System.Drawing.Size(216, 23);
            this.btnWhere.TabIndex = 24;
            this.btnWhere.Text = "Where()";
            this.btnWhere.UseVisualStyleBackColor = true;
            this.btnWhere.Click += new System.EventHandler(this.btnWhere_Click);
            // 
            // btnThenBy
            // 
            this.btnThenBy.Location = new System.Drawing.Point(8, 251);
            this.btnThenBy.Name = "btnThenBy";
            this.btnThenBy.Size = new System.Drawing.Size(216, 23);
            this.btnThenBy.TabIndex = 23;
            this.btnThenBy.Text = "ThenBy()";
            this.btnThenBy.UseVisualStyleBackColor = true;
            this.btnThenBy.Click += new System.EventHandler(this.btnThenBy_Click);
            // 
            // btnThenByDescending
            // 
            this.btnThenByDescending.Location = new System.Drawing.Point(8, 280);
            this.btnThenByDescending.Name = "btnThenByDescending";
            this.btnThenByDescending.Size = new System.Drawing.Size(216, 23);
            this.btnThenByDescending.TabIndex = 22;
            this.btnThenByDescending.Text = "ThenByDescending()";
            this.btnThenByDescending.UseVisualStyleBackColor = true;
            this.btnThenByDescending.Click += new System.EventHandler(this.btnThenByDescending_Click);
            // 
            // btnOrderByDescending
            // 
            this.btnOrderByDescending.Location = new System.Drawing.Point(8, 222);
            this.btnOrderByDescending.Name = "btnOrderByDescending";
            this.btnOrderByDescending.Size = new System.Drawing.Size(216, 23);
            this.btnOrderByDescending.TabIndex = 21;
            this.btnOrderByDescending.Text = "OrderByDescending";
            this.btnOrderByDescending.UseVisualStyleBackColor = true;
            this.btnOrderByDescending.Click += new System.EventHandler(this.btnOrderByDescending_Click);
            // 
            // btnSelectMany
            // 
            this.btnSelectMany.Location = new System.Drawing.Point(8, 77);
            this.btnSelectMany.Name = "btnSelectMany";
            this.btnSelectMany.Size = new System.Drawing.Size(216, 23);
            this.btnSelectMany.TabIndex = 20;
            this.btnSelectMany.Text = "SelectMany()";
            this.btnSelectMany.UseVisualStyleBackColor = true;
            this.btnSelectMany.Click += new System.EventHandler(this.btnSelectMany_Click);
            // 
            // btnSelect
            // 
            this.btnSelect.Location = new System.Drawing.Point(8, 48);
            this.btnSelect.Name = "btnSelect";
            this.btnSelect.Size = new System.Drawing.Size(216, 23);
            this.btnSelect.TabIndex = 19;
            this.btnSelect.Text = "Select()";
            this.btnSelect.UseVisualStyleBackColor = true;
            this.btnSelect.Click += new System.EventHandler(this.btnSelect_Click);
            // 
            // btnOrderBy
            // 
            this.btnOrderBy.Location = new System.Drawing.Point(8, 193);
            this.btnOrderBy.Name = "btnOrderBy";
            this.btnOrderBy.Size = new System.Drawing.Size(216, 23);
            this.btnOrderBy.TabIndex = 18;
            this.btnOrderBy.Text = "OrderBy()";
            this.btnOrderBy.UseVisualStyleBackColor = true;
            this.btnOrderBy.Click += new System.EventHandler(this.btnOrderBy_Click);
            // 
            // btnGroupJoin
            // 
            this.btnGroupJoin.Location = new System.Drawing.Point(8, 164);
            this.btnGroupJoin.Name = "btnGroupJoin";
            this.btnGroupJoin.Size = new System.Drawing.Size(216, 23);
            this.btnGroupJoin.TabIndex = 17;
            this.btnGroupJoin.Text = "GroupJoin()";
            this.btnGroupJoin.UseVisualStyleBackColor = true;
            this.btnGroupJoin.Click += new System.EventHandler(this.btnGroupJoin_Click);
            // 
            // btnJoin
            // 
            this.btnJoin.Location = new System.Drawing.Point(8, 135);
            this.btnJoin.Name = "btnJoin";
            this.btnJoin.Size = new System.Drawing.Size(216, 23);
            this.btnJoin.TabIndex = 16;
            this.btnJoin.Text = "Join()";
            this.btnJoin.UseVisualStyleBackColor = true;
            this.btnJoin.Click += new System.EventHandler(this.btnJoin_Click);
            // 
            // btnGroupBy
            // 
            this.btnGroupBy.Location = new System.Drawing.Point(8, 106);
            this.btnGroupBy.Name = "btnGroupBy";
            this.btnGroupBy.Size = new System.Drawing.Size(216, 23);
            this.btnGroupBy.TabIndex = 14;
            this.btnGroupBy.Text = "GroupBy()";
            this.btnGroupBy.UseVisualStyleBackColor = true;
            this.btnGroupBy.Click += new System.EventHandler(this.btnGroupBy_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnAsQuerable);
            this.groupBox2.Controls.Add(this.btnImplementQueryableBySelf);
            this.groupBox2.Controls.Add(this.btnExpressionSample3);
            this.groupBox2.Controls.Add(this.btnQuerableIntroduce);
            this.groupBox2.Location = new System.Drawing.Point(721, 205);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(229, 237);
            this.groupBox2.TabIndex = 15;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Quryable";
            // 
            // btnAsQuerable
            // 
            this.btnAsQuerable.Location = new System.Drawing.Point(6, 58);
            this.btnAsQuerable.Name = "btnAsQuerable";
            this.btnAsQuerable.Size = new System.Drawing.Size(216, 23);
            this.btnAsQuerable.TabIndex = 7;
            this.btnAsQuerable.Text = "AsQuerable()";
            this.btnAsQuerable.UseVisualStyleBackColor = true;
            this.btnAsQuerable.Click += new System.EventHandler(this.btnAsQuerable_Click);
            // 
            // btnImplementQueryableBySelf
            // 
            this.btnImplementQueryableBySelf.Location = new System.Drawing.Point(7, 116);
            this.btnImplementQueryableBySelf.Name = "btnImplementQueryableBySelf";
            this.btnImplementQueryableBySelf.Size = new System.Drawing.Size(216, 23);
            this.btnImplementQueryableBySelf.TabIndex = 6;
            this.btnImplementQueryableBySelf.Text = "Implement By Self";
            this.btnImplementQueryableBySelf.UseVisualStyleBackColor = true;
            this.btnImplementQueryableBySelf.Click += new System.EventHandler(this.btnImplementQueryableBySelf_Click);
            // 
            // btnExpressionSample3
            // 
            this.btnExpressionSample3.Location = new System.Drawing.Point(6, 87);
            this.btnExpressionSample3.Name = "btnExpressionSample3";
            this.btnExpressionSample3.Size = new System.Drawing.Size(216, 23);
            this.btnExpressionSample3.TabIndex = 3;
            this.btnExpressionSample3.Text = "Expression && IQuerable";
            this.btnExpressionSample3.UseVisualStyleBackColor = true;
            this.btnExpressionSample3.Click += new System.EventHandler(this.btnExpressionSample3_Click);
            // 
            // btnQuerableIntroduce
            // 
            this.btnQuerableIntroduce.Location = new System.Drawing.Point(6, 29);
            this.btnQuerableIntroduce.Name = "btnQuerableIntroduce";
            this.btnQuerableIntroduce.Size = new System.Drawing.Size(216, 23);
            this.btnQuerableIntroduce.TabIndex = 0;
            this.btnQuerableIntroduce.Text = "Querable Intruduce";
            this.btnQuerableIntroduce.UseVisualStyleBackColor = true;
            this.btnQuerableIntroduce.Click += new System.EventHandler(this.btnQuerableIntruduce_Click);
            // 
            // btnUsingExpressionInIEnumerable
            // 
            this.btnUsingExpressionInIEnumerable.Location = new System.Drawing.Point(7, 77);
            this.btnUsingExpressionInIEnumerable.Name = "btnUsingExpressionInIEnumerable";
            this.btnUsingExpressionInIEnumerable.Size = new System.Drawing.Size(216, 23);
            this.btnUsingExpressionInIEnumerable.TabIndex = 4;
            this.btnUsingExpressionInIEnumerable.Text = "Using Expression In IEnumerable";
            this.btnUsingExpressionInIEnumerable.UseVisualStyleBackColor = true;
            this.btnUsingExpressionInIEnumerable.Click += new System.EventHandler(this.btnUsingExpressionInIEnumerable_Click);
            // 
            // btnExpressionSample2
            // 
            this.btnExpressionSample2.Location = new System.Drawing.Point(7, 48);
            this.btnExpressionSample2.Name = "btnExpressionSample2";
            this.btnExpressionSample2.Size = new System.Drawing.Size(216, 23);
            this.btnExpressionSample2.TabIndex = 2;
            this.btnExpressionSample2.Text = "Expression Sample2";
            this.btnExpressionSample2.UseVisualStyleBackColor = true;
            this.btnExpressionSample2.Click += new System.EventHandler(this.btnExpressionSample2_Click);
            // 
            // btnExpressionSample1
            // 
            this.btnExpressionSample1.Location = new System.Drawing.Point(6, 19);
            this.btnExpressionSample1.Name = "btnExpressionSample1";
            this.btnExpressionSample1.Size = new System.Drawing.Size(216, 23);
            this.btnExpressionSample1.TabIndex = 1;
            this.btnExpressionSample1.Text = "Expression Sample1";
            this.btnExpressionSample1.UseVisualStyleBackColor = true;
            this.btnExpressionSample1.Click += new System.EventHandler(this.btnExpressionSample1_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btnWhere);
            this.groupBox3.Controls.Add(this.btnThenByDescending);
            this.groupBox3.Controls.Add(this.btnThenBy);
            this.groupBox3.Controls.Add(this.btnSelect);
            this.groupBox3.Controls.Add(this.btnSelectMany);
            this.groupBox3.Controls.Add(this.btnOrderByDescending);
            this.groupBox3.Controls.Add(this.btnGroupBy);
            this.groupBox3.Controls.Add(this.btnOrderBy);
            this.groupBox3.Controls.Add(this.btnJoin);
            this.groupBox3.Controls.Add(this.btnGroupJoin);
            this.groupBox3.Location = new System.Drawing.Point(485, 12);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(230, 430);
            this.groupBox3.TabIndex = 16;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Query Expression to Operator Method";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.btnExpressionSample1);
            this.groupBox4.Controls.Add(this.btnUsingExpressionInIEnumerable);
            this.groupBox4.Controls.Add(this.btnExpressionSample2);
            this.groupBox4.Location = new System.Drawing.Point(721, 12);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(229, 187);
            this.groupBox4.TabIndex = 17;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Expression";
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(960, 601);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.gbPrecondition);
            this.Controls.Add(this.btnTest);
            this.Controls.Add(this.btnClose);
            this.Name = "Main";
            this.Text = "Linq Training";
            this.gbPrecondition.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnDelegate;
        private System.Windows.Forms.Button btnClosure2;
        private System.Windows.Forms.Button btnLambda;
        private System.Windows.Forms.Button btnExtender;
        private System.Windows.Forms.Button btnClosure;
        private System.Windows.Forms.Button btnTest;
        private System.Windows.Forms.GroupBox gbPrecondition;
        private System.Windows.Forms.Button btnIEnumerable;
        private System.Windows.Forms.Button btnSample;
        private System.Windows.Forms.Button btnImplementBySelf;
        private System.Windows.Forms.Button btnDelayFunction;
        private System.Windows.Forms.Button btnFunctionToQuery;
        private System.Windows.Forms.Button btnHalfFlow;
        private System.Windows.Forms.Button btnVar;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnEqualityComparer;
        private System.Windows.Forms.Button btnComparer;
        private System.Windows.Forms.Button btnOrderBy;
        private System.Windows.Forms.Button btnGroupJoin;
        private System.Windows.Forms.Button btnJoin;
        private System.Windows.Forms.Button btnCast;
        private System.Windows.Forms.Button btnGroupBy;
        private System.Windows.Forms.Button btnOrderByDescending;
        private System.Windows.Forms.Button btnSelectMany;
        private System.Windows.Forms.Button btnSelect;
        private System.Windows.Forms.Button btnThenBy;
        private System.Windows.Forms.Button btnThenByDescending;
        private System.Windows.Forms.Button btnWhere;
        private System.Windows.Forms.Button btnClosureEffect;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnImplementQueryableBySelf;
        private System.Windows.Forms.Button btnSelfMethod;
        private System.Windows.Forms.Button btnUsingExpressionInIEnumerable;
        private System.Windows.Forms.Button btnExpressionSample3;
        private System.Windows.Forms.Button btnExpressionSample2;
        private System.Windows.Forms.Button btnExpressionSample1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button btnAsEnumerable;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button btnQuerableIntroduce;
        private System.Windows.Forms.Button btnAsQuerable;
    }
}

