﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using LinQTraining.Code;
using System.Collections;
using System.Linq.Expressions;

namespace LinQTraining
{
    public partial class Main : Form
    {
        #region Event handlers

        public Main()
        {
            InitializeComponent();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnDelegate_Click(object sender, EventArgs e)
        {
            Console.WriteLine(this.Add(2, 3));

            // legacy way
            AddDelegate add = new AddDelegate(Add);
            Console.WriteLine(add(2, 4));

            // anonymous delegate
            AddDelegate add3 = new AddDelegate(delegate(int i, int j)
            {
                return i + j;
            });
            Console.WriteLine(add3(2, 7));

            // omit "new AddDelegate()"
            AddDelegate add5 = delegate(int i, int j)
            {
                return i + j;
            };
            Console.WriteLine(add5(2, 7));

            // all delegates are inherit from System.Delegate
            AddDelegate add2 = (AddDelegate)System.Delegate.CreateDelegate(typeof(AddDelegate), this, "Add");
            Console.WriteLine(add2(2, 5));
            Console.WriteLine(add2.DynamicInvoke(2, 6));

            //System.Func<T1,T2,T3,T4,TResult>
            Func<int, int, int> add4 = new Func<int, int, int>(Add);
            Console.WriteLine(add4(2, 8));

            // anonymous delegate
            Func<string, int> getLength = new Func<string, int>(delegate(string a)
            {
                return a.Length;
            });
            Console.WriteLine(getLength("abc"));

            // omit "new new Func<string, int>()"
            Func<string, int> getLength2 = delegate(string a)
            {
                return a.Length;
            };
            Console.WriteLine(getLength2("abc"));

            // omit () if no parameters
            Func<int, string> getMsg = delegate
            {
                return "no parameters";
            };
            Console.WriteLine(getMsg(7));
        }

        private void btnLambda_Click(object sender, EventArgs e)
        {
            // lambda express
            Func<int, int, int> lambda0 = delegate(int i, int j)
            {
                return i + j;
            };
            // since c#3.0, the "=>" pronounces "goes to"
            Func<int, int, int> lambda1 = (int i, int j) =>
            {
                return i + j;
            };
            Console.WriteLine(lambda0(1, 2));
            Console.WriteLine(lambda1(1, 2));

            // omit parameter type
            Func<int, int, int> lambda3 = (i, j) =>
            {
                return i + j;
            };
            Console.WriteLine(lambda3(1, 2));

            // omit {} : when there is only single statement
            Func<int, int, int> lambda2 = (i, j) => i + j;
            Console.WriteLine(lambda2(1, 2));

            // when there is no parameter, the parenthesis "()" can not be ignored
            Func<string> lambda4 = () => "abc";
            Console.WriteLine(lambda4());

            // when there is only one parameter, the parenthesis "()" can be ignored
            Func<int, string> lambda5 = a => a.ToString();
            Console.WriteLine(lambda5(8));

            // parameter(s) is not used in the statement, the parameters can not be ignored in Lambda express, which is different from anonymous delegate.
            Func<int, string> lambda6 = a => "123";
            Console.WriteLine(lambda6(9));
        }

        private void btnClosure_Click(object sender, EventArgs e)
        {
            Book book = new Book()
            {
                Name = "ASP.NET Programming",
                Price = 1
            };

            Func<string> func1 = () =>
            {
                // capture external variables
                book.Name = "C# Language";
                book.Price = 10;

                return String.Format("BookName: {0}, Price: {1}", book.Name, book.Price);
            };

            Func<string> func2 = () =>
            {
                // share external variables (share status) between anonymous methods
                return String.Format("BookName: {0}, Price: {1}", book.Name, book.Price);
            };

            Console.WriteLine(func2());
            Console.WriteLine(func1());
            Console.WriteLine(func2());
        }

        private void btnClosure2_Click(object sender, EventArgs e)
        {
            Func<List<Func<string>>> createClosureList = () =>
            {
                Book book = new Book()
                {
                    Name = "ASP.NET Programming",
                    Price = 1
                };

                List<Func<string>> result = new List<Func<string>>();

                Func<string> func1 = () =>
                {
                    book.Name = "C# Language";
                    book.Price = 12;

                    return String.Format("BookName: {0}, Price: {1}", book.Name, book.Price);
                };
                result.Add(func1);

                Func<string> func2 = () =>
                {
                    return String.Format("BookName: {0}, Price: {1}", book.Name, book.Price);
                };
                result.Add(func2);

                return result;
            };

            // the var book is still alive
            List<Func<string>> funcList = createClosureList();
            //Console.WriteLine(funcList[1]());
            //Console.WriteLine(funcList[0]());
            //Console.WriteLine(funcList[1]());

            //Console.WriteLine(createClosureList()[1]());

            Func<int, Func<int, int>> a = (int x) => (int y) => x += y;

            var b1 = a(1);
            var b2 = a(100);

            b1(2);

            Console.WriteLine(b1(2).ToString());
            Console.WriteLine(b2(100).ToString());

            Func<int, Func<int, int>> a1 = (int x) =>
                {
                    Temp_01 temp = new Temp_01();
                    temp.x = x;
                    return temp.Temp_method_01;
                };

            var ba1 = a1(1);
            var ba2 = a1(100);

            ba1(2);

            Console.WriteLine(ba1(2).ToString());
            Console.WriteLine(ba2(100).ToString());

            Func<Func<int, int>> d1 = () =>
                {
                    Book book = new Book();
                    book.Price = 10;
                    return (int y) =>
                    {
                        book.Price += 10;
                        return book.Price + y;
                    };
                };

            var m1 = d1();
            m1(10);
            var m2 = d1();

            Console.WriteLine(m2(10).ToString());
            Console.WriteLine(m1(10).ToString());
        }

        public class Temp_01
        {
            public int x;

            public int Temp_method_01(int y)
            {
                return x += y;
            }
        }

        private void btnExtender_Click(object sender, EventArgs e)
        {
            Book book = new Book()
            {
                Name = "C# Language",
                Price = 10
            };

            book.RaisePrice(3);

            Console.WriteLine(book.Price);

            // System.Linq.Enumerable
            // System.Linq.Queryable
        }

        private void btnIEnumerable_Click(object sender, EventArgs e)
        {
            EnumerableAuthor author = new EnumerableAuthor("Johnson");
            author.Books = new List<Book>();

            author.Books.Add(new Book()
            {
                Name = "C# Language",
                Price = 10
            });

            author.Books.Add(new Book()
            {
                Name = "ASP.NET Programming",
                Price = 10
            });

            foreach (Book book in author)
            {
                Console.WriteLine(book.Name);
            }

            foreach (Book book in author)
            {
                Console.WriteLine(book.Name);
            }
        }

        private void btnVar_Click(object sender, EventArgs e)
        {
            Book book0 = new Book();
            book0.Name = "Johnson";
            book0.Author = "ASP.NET Programming";
            book0.Price = 10;

            var book01 = new Book();
            book01.Name = "Johnson";
            book01.Author = "ASP.NET Programming";
            book01.Price = 10;

            var book = new Book() // get; set;
            {
                Author = "Johnson",
                Name = "ASP.NET Programming",
                Price = 10
            };
            Console.WriteLine(book.GetType().FullName);

            // Object >> AnonymousType
            var obj = new // anonymous object
            {
                Name = "Johnson",
                Address = "Guangzhou"
            };

            object obj2 = new // anonymous object
            {
                Name = "Johnson",
                Address = "Guangzhou"
            };

            // Javascript: var userObject = { "property1" : 123, property2 : "My Property Value" };
        }

        private void btnSample_Click(object sender, EventArgs e)
        {
            var q = from book in DataContext.Books
                    where book.Price > 300
                    select book;

            Console.WriteLine(q.GetType().FullName);

            foreach (Book b in q)
            {
                Console.WriteLine("Name: {0}, Author: {1}, Price: {2}", b.Name, b.Author, b.Price);
            }
        }

        private void btnFunctionToQuery_Click(object sender, EventArgs e)
        {
            var books = DataContext.Books.Where(book => book.Price > 300).Select(book => new
            {
                Name = book.Name,
                Price = book.Price
            }).OrderByDescending(book => book.Price);

            foreach (var b in books)
            {
                Console.WriteLine("Name: {0}, Price: {1}", b.Name, b.Price);
            }

            Console.WriteLine("====================================");

            // A query body must start in "from in" clause
            // A query body must end with a "select" clause or a "group" clause
            var books2 = from book in DataContext.Books
                         where book.Price > 300
                         orderby book.Price descending
                         select new
                         {
                             Name = book.Name,
                             Price = book.Price
                         };
            foreach (var b in books2)
            {
                Console.WriteLine("Name: {0}, Price: {1}", b.Name, b.Price);
            }
        }

        private void btnSelfMethod_Click(object sender, EventArgs e)
        {
            // Two way to use the query grammar:
            // Implementing the IEnumerable<(Of <(T>)>) interface in a type to enable LINQ to Objects querying of that type.
            // Creating standard query operator methods such as Where and Select that extend a type, to enable custom LINQ querying of that type.

            MyIEnumerableClass a = new MyIEnumerableClass();
            a.Items.Add("Banana");
            a.Items.Add("Apear");
            a.Items.Add("bin");
            // a.Where()
            var q2 = from i in a
                     where i.Length > 1
                     select i;

            // var q2 = a.Where(i => i.Length > 1);

            foreach (string i in q2)
            {
                Console.WriteLine(i);
            }
        }

        private void btnImplementBySelf_Click(object sender, EventArgs e)
        {
            IEnumerable<Book> books = DataContext.Books.Where(book => book.Price > 300);
            foreach (Book b in books)
            {
                Console.WriteLine("Name: {0}, Price: {1}", b.Name, b.Price);
            }

            Console.WriteLine("====================================");

            // get result right away (immediately execution)
            IEnumerable<Book> books2 = DataContext.Books.MyWhere(book => book.Price > 300);

            foreach (Book b in books2)
            {
                Console.WriteLine("Name: {0}, Price: {1}", b.Name, b.Price);
            }

            Console.WriteLine("====================================");

            // a more complicated example
            //var books3 = DataContext.Authors.SelectMany(author => author.Books);

            //foreach(string b in books3)
            //{
            //    Console.WriteLine(b);
            //}

            //Console.WriteLine();

            //var books4 = DataContext.Authors.MySelectMany(author => author.Books);

            //foreach(string b in books4)
            //{
            //    Console.WriteLine(b);
            //}

            //Console.WriteLine();

        }

        private void btnDelayFunction_Click(object sender, EventArgs e)
        {
            IEnumerable<Book> books2 = DataContext.Books.MyWhere2(book => book.Price > 300);

            foreach (Book b in books2)
            {
                Console.WriteLine("Name: {0}, Price: {1}", b.Name, b.Price);
            }

            Console.WriteLine("====================================");

            // implement it by self
            IEnumerable<Book> books3 = DataContext.Books.MyWhere3(book => book.Price > 300);
            foreach (Book b in books3)
            {
                Console.WriteLine("Name: {0}, Price: {1}", b.Name, b.Price);
            }

            Console.WriteLine("====================================");
        }

        private void btnHalfFlow_Click(object sender, EventArgs e)
        {
            var q = DataContext.Authors.GroupJoin(DataContext.Books,
                author => author.Name,
                book => book.Author,
                (author, books) => new { Author = author.Name, Books = books });
            foreach (var i in q)
            {
                Console.WriteLine("Key: {0} ------------------", i.Author);

                foreach (Book b in i.Books)
                    Console.WriteLine("Name: {0}, Author: {1}, Price: {2}", b.Name, b.Author, b.Price);
            }

            Console.WriteLine("====================================");


            var q2 = DataContext.Authors.MyGroupJoin(DataContext.Books,
                author => author.Name,
                book => book.Author,
                (author, books) => new { Author = author.Name, Books = books });
            foreach (var i in q2)
            {
                Console.WriteLine("Key: {0} ------------------", i.Author);

                foreach (Book b in i.Books)
                    Console.WriteLine("Name: {0}, Author: {1}, Price: {2}", b.Name, b.Author, b.Price);
            }
        }

        private void btnComparer_Click(object sender, EventArgs e)
        {
            // Book must implement IComparable interface
            var q = DataContext.Publishers.OrderBy(publisher => publisher.Book);
            foreach (var p in q)
            {
                Console.WriteLine("Name: {0}, BookName: {1}", p.Name, p.Book.Name);
            }

            Console.WriteLine("====================================");

            var q2 = DataContext.Publishers.OrderBy(publisher => publisher.Book,
                    new MyComparer<Book>((book1, book2) => book1.Name.Length.CompareTo(book2.Name.Length)));

            foreach (var p in q2)
            {
                Console.WriteLine("Name: {0}, BookName: {1}", p.Name, p.Book.Name);
            }
        }

        private void btnEqualityComparer_Click(object sender, EventArgs e)
        {
            Console.WriteLine();

            var q = DataContext.Writers.Join(DataContext.Publishers,
                writer => writer.Book,
                publisher => publisher.Book,
                (writer, publisher) => new
                {
                    Writer = writer.Name,
                    Publisher = publisher.Name,
                    Book = writer.Book.Name
                });

            // removing the Book.Equals() and Book.GetHashCode() implementation will out put nothing
            // because it will call Object's default Equals() and GetHashCode() implementation, which always not equal
            foreach (var b in q)
            {
                Console.WriteLine("Writer: {0}, Publisher: {1}, Book: {2}", b.Writer, b.Publisher, b.Book);
            }

            Console.WriteLine("====================================");

            var q2 = DataContext.Writers.Join(DataContext.Publishers,
                writer => writer.Book,
                publisher => publisher.Book,
                (writer, publisher) => new
                {
                    Writer = writer.Name,
                    Publisher = publisher.Name,
                    Book = writer.Book.Name
                },
                new BookEqualityComparer());

            foreach (var b in q2)
            {
                //Console.WriteLine("Writer: {0}, Publisher: {1}, Book: {2}", b.Writer, b.Publisher, b.Book);
            }
        }

        private void btnCast_Click(object sender, EventArgs e)
        {
            ArrayList fruits = new ArrayList();
            fruits.Add("apple");
            fruits.Add("mango");


            IEnumerable<string> query = fruits.Cast<string>().Select(fruit => fruit);
            foreach (string fruit in query)
                Console.WriteLine(fruit);

            Console.WriteLine("====================================");

            IEnumerable<string> query2 = from string f in fruits select f;
            foreach (string fruit in query2)
                Console.WriteLine(fruit);
        }

        private void btnGroupBy_Click(object sender, EventArgs e)
        {
            IEnumerable<IGrouping<string, Book>> q = DataContext.Books.GroupBy(book => book.Author);
            foreach (var g in q)
            {
                Console.WriteLine("Key: {0} ------------------", g.Key);

                foreach (Book b in g)
                    Console.WriteLine("Name: {0}, Author: {1}, Price: {2}", b.Name, b.Author, b.Price);
            }

            Console.WriteLine("====================================");

            IEnumerable<IGrouping<string, Book>> q2 = from book in DataContext.Books
                                                      group book by book.Author;
            foreach (var g in q2)
            {
                Console.WriteLine("Key: {0} ------------------", g.Key);

                foreach (Book b in g)
                    Console.WriteLine("Name: {0}, Author: {1}, Price: {2}", b.Name, b.Author, b.Price);
            }
        }

        private void btnJoin_Click(object sender, EventArgs e)
        {
            var q = DataContext.Books.Join(DataContext.Authors, book => book.Author, author => author.Name,
                (book, author) => new { Book = book.Name, Author = author.Name, Age = author.Age });
            foreach (var b in q)
            {
                Console.WriteLine("Book: {0}, Author: {1}, Age: {2}", b.Book, b.Author, b.Age);
            }

            Console.WriteLine("====================================");

            var q2 = from book in DataContext.Books
                     join author in DataContext.Authors on book.Author equals author.Name // the sequence is: outerKey equals innerKey
                     select new { Book = book.Name, Author = author.Name, Age = author.Age };

            foreach (var b in q)
            {
                Console.WriteLine("Book: {0}, Author: {1}, Age: {2}", b.Book, b.Author, b.Age);
            }
        }

        private void btnGroupJoin_Click(object sender, EventArgs e)
        {
            var q = DataContext.Authors.GroupJoin(DataContext.Books,
                author => author.Name,
                book => book.Author,
                (author, books) => new { Author = author.Name, Books = books });
            foreach (var i in q)
            {
                Console.WriteLine("Key: {0} ------------------", i.Author);

                foreach (Book b in i.Books)
                    Console.WriteLine("Name: {0}, Author: {1}, Price: {2}", b.Name, b.Author, b.Price);
            }

            Console.WriteLine("====================================");

            var q2 = from author in DataContext.Authors
                     join book in DataContext.Books on author.Name equals book.Author into books
                     select new { Author = author.Name, Books = books };
            foreach (var i in q2)
            {
                Console.WriteLine("Key: {0} ------------------", i.Author);

                foreach (Book b in i.Books)
                    Console.WriteLine("Name: {0}, Author: {1}, Price: {2}", b.Name, b.Author, b.Price);
            }
        }

        private void btnOrderBy_Click(object sender, EventArgs e)
        {
            IEnumerable<Book> q = DataContext.Books.OrderBy(book => book.Price);
            foreach (Book b in q)
            {
                Console.WriteLine("Name: {0}, Author: {1}, Price: {2}", b.Name, b.Author, b.Price);
            }

            Console.WriteLine("====================================");

            IEnumerable<Book> q2 = from book in DataContext.Books
                                   orderby book.Price
                                   select book;
            foreach (Book b in q2)
            {
                Console.WriteLine("Name: {0}, Author: {1}, Price: {2}", b.Name, b.Author, b.Price);
            }
        }

        private void btnOrderByDescending_Click(object sender, EventArgs e)
        {
            IEnumerable<Book> q = DataContext.Books.OrderByDescending(book => book.Price);
            foreach (Book b in q)
            {
                Console.WriteLine("Name: {0}, Author: {1}, Price: {2}", b.Name, b.Author, b.Price);
            }

            Console.WriteLine("====================================");

            IEnumerable<Book> q2 = from book in DataContext.Books
                                   orderby book.Price descending
                                   select book;
            foreach (Book b in q2)
            {
                Console.WriteLine("Name: {0}, Author: {1}, Price: {2}", b.Name, b.Author, b.Price);
            }
        }

        private void btnSelect_Click(object sender, EventArgs e)
        {
            var q = DataContext.Books.Select(book => new { N = book.Name, P = book.Price });
            foreach (var b in q)
            {
                Console.WriteLine("N: {0}, P: {1}", b.N, b.P);
            }

            Console.WriteLine("====================================");

            var q2 = from book in DataContext.Books
                     select new { N = book.Name, P = book.Price };
            foreach (var b in q2)
            {
                Console.WriteLine("N: {0}, P: {1}", b.N, b.P);
            }
        }

        private void btnSelectMany_Click(object sender, EventArgs e)
        {
            IEnumerable<string> q = DataContext.Authors.SelectMany(author => author.Books);
            foreach (string b in q)
            {
                Console.WriteLine(b);
            }

            Console.WriteLine("====================================");

            IEnumerable<string> q2 = from author in DataContext.Authors
                                     from book in author.Books
                                     select book;
            foreach (string b in q2)
            {
                Console.WriteLine(b);
            }
        }

        private void btnThenBy_Click(object sender, EventArgs e)
        {
            IOrderedEnumerable<Book> q = DataContext.Books.OrderBy(book => book.Price).ThenBy(book => book.Name);
            foreach (Book b in q)
            {
                Console.WriteLine("Name: {0}, Author: {1}, Price: {2}", b.Name, b.Author, b.Price);
            }

            Console.WriteLine("====================================");

            IOrderedEnumerable<Book> q2 = from book in DataContext.Books
                                          orderby book.Price, book.Name
                                          select book;
            // wrong: 
            //orderby book.Price, 
            //orderby book.Name

            foreach (Book b in q2)
            {
                Console.WriteLine("Name: {0}, Author: {1}, Price: {2}", b.Name, b.Author, b.Price);
            }
        }

        private void btnThenByDescending_Click(object sender, EventArgs e)
        {
            IOrderedEnumerable<Book> q = DataContext.Books.OrderBy(book => book.Price).ThenByDescending(book => book.Name);
            foreach (Book b in q)
            {
                Console.WriteLine("Name: {0}, Author: {1}, Price: {2}", b.Name, b.Author, b.Price);
            }

            Console.WriteLine("====================================");

            IOrderedEnumerable<Book> q2 = from book in DataContext.Books
                                          orderby book.Price ascending, book.Name descending
                                          select book;
            foreach (Book b in q2)
            {
                Console.WriteLine("Name: {0}, Author: {1}, Price: {2}", b.Name, b.Author, b.Price);
            }
        }

        private void btnWhere_Click(object sender, EventArgs e)
        {
            IEnumerable<Book> q = DataContext.Books.Where(book => book.Price > 300);
            foreach (Book b in q)
            {
                Console.WriteLine("Name: {0}, Author: {1}, Price: {2}", b.Name, b.Author, b.Price);
            }

            Console.WriteLine("====================================");

            IEnumerable<Book> q2 = from book in DataContext.Books
                                   where book.Price > 300
                                   select book;
            foreach (Book b in q2)
            {
                Console.WriteLine("Name: {0}, Author: {1}, Price: {2}", b.Name, b.Author, b.Price);
            }
        }

        private void btnClosureEffect_Click(object sender, EventArgs e)
        {
            Book book = new Book() { Name = "Javascript Language", Author = "Johnson", Price = 45 };

            IEnumerable<Book> q = DataContext.Books.Where(b =>
            {
                book.Price += 100;
                return book.Price > book.Price;
            });

            // does not take effect now
            Console.WriteLine(book.Price);

            foreach (Book b in q)
            { }

            Console.WriteLine(book.Price);
        }

        private void btnAsEnumerable_Click(object sender, EventArgs e)
        {
            MyList<string> myList = new MyList<string> {"apple", "passionfruit", "banana", 
            "mango", "orange", "blueberry", "grape", "strawberry"};

            IEnumerable<string> q1 = myList.Where(fruit => fruit.Contains('o'));
            foreach (string f in q1)
            {
                ;
            }

            Console.WriteLine("====================================");

            IEnumerable<string> q2 = myList.AsEnumerable().Where(fruit => fruit.Contains('o'));
            foreach (string f in q2)
            {
                ;
            }

        }

        private void btnExpressionSample1_Click(object sender, EventArgs e)
        {
            bool result;

            string name = "Johnson";
            result = name.ToLower() == "johnson";

            Console.WriteLine(result);

            // ------------ name.ToLower() == "johnson" --------------
            // name
            ParameterExpression nameParameter = Expression.Parameter(typeof(string), "name");
            // name.ToLower()
            MethodCallExpression left = Expression.Call(nameParameter, typeof(string).GetMethod("ToLower", Type.EmptyTypes));
            // "johnson"
            ConstantExpression right = Expression.Constant("johnson");
            // name.ToLower() == "johnson"
            BinaryExpression exp = Expression.Equal(left, right);

            // ----------- name => name.ToLower() == "johnson" ------------
            Expression<Func<string, bool>> lambdaExp = Expression.Lambda<Func<string, bool>>(exp, nameParameter);

            Func<string, bool> func = lambdaExp.Compile();
            result = func(name);

            Console.WriteLine(result);
        }

        private void btnExpressionSample2_Click(object sender, EventArgs e)
        {
            bool result;

            string name = "Johnson";
            result = name.ToLower() == "john" || name.Length > 6;

            Console.WriteLine(result);

            // ------------- name.ToLower() == "johnson" --------------
            // name
            ParameterExpression nameParameter = Expression.Parameter(typeof(string), "name");
            // name.ToLower()
            MethodCallExpression left = Expression.Call(nameParameter, typeof(string).GetMethod("ToLower", Type.EmptyTypes));
            // "johnson"
            ConstantExpression right = Expression.Constant("johnson");
            // name.ToLower() == "johnson"
            BinaryExpression exp1 = Expression.Equal(left, right);


            // ----------- name.Length > 6 ---------------
            // name.Length
            MemberExpression memberExpression = Expression.Property(nameParameter, "Length");
            // 6
            ConstantExpression right2 = Expression.Constant(6);
            // name.Length > 6
            BinaryExpression exp2 = Expression.GreaterThan(memberExpression, right2);


            // ------------ name.ToLower() == "john" || name.Length > 6 -------------
            BinaryExpression exp = Expression.OrElse(exp1, exp2);

            // ------------ name => name.ToLower() == "john" || name.Length > 6 --------------
            Expression<Func<string, bool>> lambdaExp = Expression.Lambda<Func<string, bool>>(exp, nameParameter);

            Func<string, bool> func = lambdaExp.Compile();
            result = func(name);
            Console.WriteLine(result);
        }

        private void btnUsingExpressionInIEnumerable_Click(object sender, EventArgs e)
        {
            ParameterExpression para = Expression.Parameter(typeof(Book), "book");
            MemberExpression exp2 = Expression.Property(para, "Price");
            ConstantExpression exp3 = Expression.Constant(300);
            BinaryExpression exp4 = Expression.GreaterThan(exp2, exp3);

            Expression<Func<Book, bool>> exp5 = Expression.Lambda<Func<Book, bool>>(exp4, para);

            IEnumerable<Book> q2 = DataContext.Books.Where(exp5.Compile());

            foreach (Book b in q2)
            {
                Console.WriteLine("Name: {0}, Author: {1}, Price: {2}", b.Name, b.Author, b.Price);
            }
        }

        private void btnQuerableIntruduce_Click(object sender, EventArgs e)
        {
            //IQueryable
            //Queryable

            Console.WriteLine("====================================");

            IQueryable<Book> books = DataContext.Books.AsQueryable<Book>();
            var q = from book in books
                    where book.Price > 300
                    orderby book.Price
                    select book.Price;

            foreach (int p in q)
            {
                Console.WriteLine(p);
            }
        }

        private void btnAsQuerable_Click(object sender, EventArgs e)
        {
            int[] ages = { 1, 3, 5, 7 };
            IQueryable<int> querableAges = ages.AsQueryable<int>();

            var q = from age in querableAges
                    where age > 4
                    select age;

            foreach (int p in q)
            {
                Console.WriteLine(p);
            }

            Console.WriteLine("====================================");

            // queryableData.Provider is "System.Linq.EnumerableQuery"

            // "Johnson".Length
            ConstantExpression name = Expression.Constant("Johnson", typeof(string));
            MemberExpression length = Expression.Property(name, "Length");

            int results2 = querableAges.Provider.Execute<int>(length);
            Console.WriteLine(results2);
        }

        private void btnExpressionSample3_Click(object sender, EventArgs e)
        {
            string[] companies = { "Consolidated Messenger", "Alpine Ski House", "Southridge Video", "City Power & Light",
                   "Coho Winery", "Wide World Importers", "Graphic Design Institute", "Adventure Works",
                   "Humongous Insurance", "Woodgrove Bank", "Margie's Travel", "Northwind Traders",
                   "Blue Yonder Airlines", "Trey Research", "The Phone Company",
                   "Wingtip Toys", "Lucerne Publishing", "Fourth Coffee" };

            IQueryable<String> queryableData = companies.AsQueryable<string>();

            // companies.Where(company => (company.ToLower() == "coho winery" || company.Length > 16)).OrderBy(company => company);

            Console.WriteLine("====================================");

            // ------------- company.ToLower() == "coho winery" ------------------------
            ParameterExpression companyParameter = Expression.Parameter(typeof(string), "company");
            MethodCallExpression toLower = Expression.Call(companyParameter, typeof(string).GetMethod("ToLower", Type.EmptyTypes));
            ConstantExpression right1 = Expression.Constant("coho winery");
            BinaryExpression exp1 = Expression.Equal(toLower, right1);

            // ------------- company.Length > 16 ---------------------
            MemberExpression left2 = Expression.Property(companyParameter, "Length");
            ConstantExpression right2 = Expression.Constant(16);
            BinaryExpression exp2 = Expression.GreaterThan(left2, right2);

            // ------------- company.ToLower() == "coho winery" || company.Length > 16 ------------------
            BinaryExpression exp3 = Expression.OrElse(exp1, exp2);

            // ------------- company => (company.ToLower() == "coho winery" || company.Length > 16) -------------------
            Expression<Func<string, bool>> exp4 = Expression.Lambda<Func<string, bool>>(exp3, companyParameter);

            IQueryable<string> results0 = queryableData.Where(exp4);

            foreach (string company in results0)
            {
                Console.WriteLine(company);
            }

            Console.WriteLine("====================================");

            // ------------- .Where(company => (company.ToLower() == "coho winery" || company.Length > 16)) -----------------
            // ((ConstantExpression)queryableData.Expression).Value is the string array 
            MethodCallExpression whereCallExpression = Expression.Call(typeof(Queryable), "Where",
                new Type[] { queryableData.ElementType }, queryableData.Expression, exp4);

            // ------------- whereCallExpression.OrderBy(company => company) -------------------
            // company => company
            Expression<Func<string, string>> exp5 = Expression.Lambda<Func<string, string>>(companyParameter, companyParameter);
            // whereCallExpression.OrderBy(...)
            MethodCallExpression orderByCallExpression = Expression.Call(typeof(Queryable), "OrderBy",
                new Type[] { queryableData.ElementType, queryableData.ElementType }, whereCallExpression, exp5);

            // queryableData.Provider is "System.Linq.EnumerableQuery"
            IQueryable<string> results = queryableData.Provider.CreateQuery<string>(orderByCallExpression);
            foreach (string company in results)
            {
                Console.WriteLine(company);
            }

            Console.WriteLine("====================================");
        }

        private void btnImplementQueryableBySelf_Click(object sender, EventArgs e)
        {
            IQueryable<Book> books = DataContext.Books.AsQueryable<Book>();

            Expression<Func<Book, bool>> whereExp = (book => book.Price > 300);
            Expression<Func<Book, int>> orderByExp = (book => book.Price);
            Expression<Func<Book, int>> selectExp = (book => book.Price);

            IQueryable<int> q = books.MyQWhere(whereExp).MyQOrderBy<Book, int>(orderByExp).MyQSelect<Book, int>(selectExp);

            foreach (int b in q)
            {
                Console.WriteLine(b);
            }

            //foreach (Book b in q)
            //{
            //    Console.WriteLine("Name: {0}, Author: {1}, Price: {2}", b.Name, b.Author, b.Price);
            //}
        }

        private void btnTest_Click(object sender, EventArgs e)
        {
        }

        #endregion

        delegate int AddDelegate(int i, int j);

        #region Helper methods

        private int Add(int a, int b)
        {
            return a + b;
        }

        #endregion
    }
}
